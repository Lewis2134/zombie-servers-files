ui_page "index.html"

files {
	"zombiedoorbang.ogg",
	"index.html",
}

client_script 'client.lua'
